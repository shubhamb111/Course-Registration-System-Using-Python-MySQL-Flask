# simple-login-page-using-python-mysql-Flask
create a database. in that create table using this schema : create table login_table( user_name varchar(30), email varchar(40), password varchar(20) );

this is a simple login page for an academy. in this project i have used flask, python and mysql.
