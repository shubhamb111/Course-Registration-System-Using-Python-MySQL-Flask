# User Credentials
host = 'localhost'
user = 'asavariproject'
password = 'asavari@123'
database = 'student_database'